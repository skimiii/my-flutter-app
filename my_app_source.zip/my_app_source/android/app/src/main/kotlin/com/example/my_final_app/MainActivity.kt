package com.example.my_final_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
